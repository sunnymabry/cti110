#Mabry Sunny
#02/23/2024
#CTI-110 P1HW1
#Assignment tests student's knowledge of how to write code that collects information from user, processes information collected and display results to user.
user_num = int(input('Enter integer:\n'))

# Type your code here
print('You entered:',user_num)
print(user_num, 'squared is', user_num * user_num)
print('And', user_num, 'cubed is', user_num * user_num * user_num, '!!')
user_num2 = int(input('Enter another integer:\n'))
print(user_num, "+", user_num2, 'is', user_num + user_num2)
print(user_num, "*", user_num2, 'is', user_num * user_num2)