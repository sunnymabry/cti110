#Sunny Mabry
#Mar. 16th, 2024
#P3LAB:Leap Year
#Assignment tests student's knowledge of how to write code that displays information to users
is_leap_year = False
   
input_year = int(input())

''' Type your code here. '''

if (input_year % 400 == 0) and (input_year % 100 == 0):
    print("{0} - leap year".format(input_year))
elif (input_year % 4 == 0) and (input_year % 100 !=0):
    print("{0} - leap year".format(input_year))
else:
    print("{0} - not a leap year".format(input_year))